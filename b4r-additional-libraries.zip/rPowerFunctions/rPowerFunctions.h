#pragma once
#include "B4RDefines.h"
#include "powerfunctions.h"
//~version: 1.0
namespace B4R {

	//~shortname: PowerFunctions
  class B4RPowerFunctions {
  	private:
  		//Define the constructor PowerFunctions
  		uint8_t backend[sizeof(PowerFunctions)];
  		PowerFunctions* pf;
  	public:
			//Init the constructor PowerFunctions with the Arduino Pin and the Channel 0 - 3
    	void Initialize(Byte Pin, Byte Channel);
      //PWM speed steps
      #define /*Byte PWM_FLT;*/ B4RPowerFunctions_PWM_FLT 0x0
      #define /*Byte PWM_FWD1;*/ B4RPowerFunctions_PWM_FWD1 0x1
      #define /*Byte PWM_FWD2;*/ B4RPowerFunctions_PWM_FWD2 0x2
      #define /*Byte PWM_FWD3;*/ B4RPowerFunctions_PWM_FWD3 0x3
      #define /*Byte PWM_FWD4;*/ B4RPowerFunctions_PWM_FWD4 0x4
      #define /*Byte PWM_FWD5;*/ B4RPowerFunctions_PWM_FWD5 0x5
      #define /*Byte PWM_FWD6;*/ B4RPowerFunctions_PWM_FWD6 0x6
      #define /*Byte PWM_FWD7;*/ B4RPowerFunctions_PWM_FWD7 0x7
      #define /*Byte PWM_BRK;*/ B4RPowerFunctions_PWM_BRK 0x8
      #define /*Byte PWM_REV7;*/ B4RPowerFunctions_PWM_REV7 0x9
      #define /*Byte PWM_REV6;*/ B4RPowerFunctions_PWM_REV6 0xA
      #define /*Byte PWM_REV5;*/ B4RPowerFunctions_PWM_REV5 0xB
      #define /*Byte PWM_REV4;*/ B4RPowerFunctions_PWM_REV4 0xC
      #define /*Byte PWM_REV3;*/ B4RPowerFunctions_PWM_REV3 0xD
      #define /*Byte PWM_REV2;*/ B4RPowerFunctions_PWM_REV2 0xE
      #define /*Byte PWM_REV1;*/ B4RPowerFunctions_PWM_REV1 0xf

      //Output defined the RED or BLUE side of the IR Receiver
      #define /*Byte RED;*/ 	B4RPowerFunctions_RED 0x0
      #define /*Byte BLUE;*/ B4RPowerFunctions_BLUE 0x1

			//Channels
			#define /*Byte CHANNEL1;*/ B4RPowerFunctions_CHANNEL1 	0x0
			#define /*Byte CHANNEL2;*/ B4RPowerFunctions_CHANNEL2 	0x1
			#define /*Byte CHANNEL3;*/ B4RPowerFunctions_CHANNEL3 	0x2
			#define /*Byte CHANNEL4;*/ B4RPowerFunctions_CHANNEL4 	0x3

      void singlePWM(UInt output, UInt pwm);
	    void singleIncrement(UInt i);
	    void singleDecrement(UInt d);
  	  void redPWM(UInt r);
    	void bluePWM(UInt b);
    	void comboPWM(UInt p, UInt v);
	};

}
