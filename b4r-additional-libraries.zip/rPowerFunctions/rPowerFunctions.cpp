#include "B4RDefines.h"
namespace B4R {
	void B4RPowerFunctions::Initialize(Byte Pin, Byte Channel) {
		pf = new (backend) PowerFunctions(Pin, Channel);
	}

	void B4RPowerFunctions::singlePWM(UInt output, UInt pwm) {
		pf->single_pwm(output, pwm);		
	}

	void B4RPowerFunctions::singleIncrement(UInt i) {
		pf->single_increment(i);
	}

	void B4RPowerFunctions::singleDecrement(UInt d) {
		pf->single_decrement(d);
	}

	void B4RPowerFunctions::redPWM(UInt r) {
		pf->red_pwm(r);
	}

	void B4RPowerFunctions::bluePWM(UInt b) {
		pf->blue_pwm(b);
	}

	void B4RPowerFunctions::comboPWM(UInt p, UInt v) {
		pf->combo_pwm(p, v);
	}


}
