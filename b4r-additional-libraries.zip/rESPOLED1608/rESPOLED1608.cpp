#include "B4RDefines.h"
namespace B4R {
		//Init the sensor with the sda and scl pin
		void B4RESPOLED1608::Initialize(Int sda, Int scl, Int address, Int offset) {
			ol = new (be) OLED(sda,scl,address,offset);
			ol->begin();
		}

		/**
		*Display ON
		*/
		void B4RESPOLED1608::On(void) {
			ol->on();
		};
		
		/**
		*Display OFF
		*/
		void B4RESPOLED1608::Off(void){
			ol->off();
		};		
		/**
		*Display Clear
		*/
		void B4RESPOLED1608::Clear(void) {
			ol->clear();
		};
		
		/**
		*Print string at row and col
		*/
		void B4RESPOLED1608::Print(B4RString* str, Int row, Int col) {
			ol->print((char*)str->data,row,col);
		};
}
