//rESPOLED1608 to display text on an OLED display. There are 16 cols and 8 rows used.
//B4R Library wrapped based on project https://github.com/remoteme/esp8266-OLED. Thanks to the author.
//Changelog
//20190912: v1.0
#pragma once
#include "B4RDefines.h"
#include "OLED.h"
namespace B4R {
	//~Version: 1.0
	//~shortname: ESPOLED1608
	//~Author: Robert W.B. Linn
	//ESP OLED lib
	class B4RESPOLED1608 {
		private:
			OLED* ol;
			uint8_t be[sizeof(OLED)];

		public:
			/**
			*Initialize the display with sda & scl pin (GPIO numbering).
			*Default address of an OLED is 0x3C.
			*Example (Private oledDisplay As ESPOLED1608):<code>
			'Init the OLED display with gpio2 (D4,SDA), gpio14 (D5,SCL)
			oledDisplay.Initialize(2,14,0x3c,0)
			oledDisplay.Print("Hello World",1,1)
			oledDisplay.Print("Enjoy B4R",4,1)
			*</code>
			*/
  		void Initialize(Int sda, Int scl, Int address, Int offset);
		
			/**
			*Turn the display ON
			*/
			void On(void);
		
			/**
			*Turn the display OFF
			*/
			void Off(void);
		
			/**
			*Clear the display
			*/
			void Clear(void);
		
			/**
			*Print a string at row and col
			*Row: 0 - 7, Col: 0 - 15
			*/
			void Print(B4RString* str, Int row, Int col);

	};
}